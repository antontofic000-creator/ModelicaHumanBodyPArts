﻿# ModelicaHumanBodyPArts v0.10.0 Release Candidate

## Purpose
ModelicaHumanBodyPArts is an equation-based Modelica library for auditable human multibody mechanics. This release candidate extends the frozen v0.9.2 baseline with generic regional plantar-load observers and corrected aggregate variable-impedance energy accounting.

## Scope
This is a mechanical research-software library. It is not a human-validated clinical model. It does not identify individual muscle forces, cartilage stresses, injury risk, or respiratory physiology.

## Environment verified in the native release campaign
- OpenModelica 1.27.1 (64-bit)
- Modelica Standard Library 4.1.0
- Windows 10/11 x64 environment
- Source SHA-256: 2fda3b797ef9304529776d0610a3a8608e233c92531924579cb2eafe6665de4b

## New generic v0.10.0 functionality
- AuditedPlantarContact: six-zone heel/midfoot/forefoot regional support outputs.
- Contact stored-energy, dissipation, power-to-body, and energy-identity diagnostics.
- Loaded-support aggregate energy accounting based on actual time-varying stiffness and damping.
- Known-load regional-contact regression.
- Heel-unloading detector regression.
- Gravity-loaded variable-impedance aggregate energy regression.

## Native verification result
The clean native campaign contains 50 registered cases: 45 runtime simulations and 5 build-only fixtures. All 50 passed from fresh build products using the release-candidate source. The run keeps source, manifest, build scripts/logs, runtime logs, executables, initialization XML, CSV results, and SHA-256 hashes.

## Reproduction
1. Install OpenModelica 1.27.1 and Modelica Standard Library 4.1.0.
2. Place the release-candidate source, v010_test_manifest.json and run_v010_native.mjs in one working directory.
3. Run: node run_v010_native.mjs
4. Confirm summary.json reports status PASS and that its source SHA-256 matches the value above.

## License
ModelicaHumanBodyPArts is released under the MIT License. See LICENSE and THIRD_PARTY_NOTICES.md.

## Important evidence distinction
A successful software regression verifies the implemented mechanical/numerical contract of that fixture. It does not establish biological validity.

## Publication status
This package is the open-source publication release candidate prepared for the SoftwareX manuscript. The software license is finalized as MIT. Public repository: https://github.com/antontofic000-creator/ModelicaHumanBodyPArts`r`n`r`nTagged release: https://github.com/antontofic000-creator/ModelicaHumanBodyPArts/releases/tag/v0.10.0`r`n`r`nAn archival DOI remains to be inserted before journal submission.
